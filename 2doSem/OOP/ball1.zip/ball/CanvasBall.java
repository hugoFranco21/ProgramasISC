package ball;

/*Author: Unknown
* Modified by: Silvana
* 12/sep/17
* Ball that moves and changes its color
*/

import ball.Ball;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.Random;
import java.util.Timer;

public class CanvasBall extends Canvas
{
        Ball[] balls = new Ball[5];
        Square[] squares = new Square[5];
        
	public CanvasBall()
	{
               Random r = new Random();
               for(int i=0; i<balls.length ; i++)
                {
                    balls[i]= new Ball(1 + r.nextInt(500),1 + r.nextInt(300),1 + r.nextInt(10),1 + r.nextInt(10)); 
                }
               
                 for(int i=0; i<squares.length ; i++)
                {
                    squares[i]= new Square(1 + r.nextInt(500),1 + r.nextInt(300),1 + r.nextInt(10),1 + r.nextInt(10)); 
                }
		enableEvents(java.awt.AWTEvent.KEY_EVENT_MASK);
		requestFocus();
		Timer t = new Timer(true);
		t.schedule( new java.util.TimerTask()
		{
			public void run()
			{
                            for (Ball ball : balls) 
                            {
                                ball.move();
                            }
                            
                            for (Square square : squares) 
                            {
                                square.move();
                            }
			    repaint();
			}
		}, 10, 10);

	}

	public void paint( Graphics g )
	{
            for (Ball ball : balls) 
            {
                ball.createBall(g);
            }
            
            for (Square square : squares) 
            {
                square.createSquare(g);
            }
	}

        //manage a key event to activate the change of color 
	public void processKeyEvent(KeyEvent e)
	{
		if ( e.getID() == KeyEvent.KEY_PRESSED )
		{
			if ( e.getKeyCode() == KeyEvent.VK_SPACE )
			{
                            for (Ball ball : balls) 
                            {
                                ball.setFlashing();
                            }
				
                            for (Square square : squares) 
                            {
                                square.setFlashing();
                            }
			}
		}
	}
	      
}
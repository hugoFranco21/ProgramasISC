package ball;

/*Author: Unknown
* Modified by: Silvana
* 12/sep/17
* Canvas that has N balls
*/

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Square {
    
    	int x, y, dx, dy;
	Color cur;
	Random rng;
	boolean flashing = false;
        
        public Square(int x, int y, int dx, int dy)
	{
		this.x = x;
		this.y = y;
		this.dx = dx;
		this.dy = dy;
		cur = Color.black;
		rng = new Random();
	}

	public Graphics createSquare( Graphics g )
	{
		g.setColor(cur);
		g.fillRect(x, y, 20, 20);
                return g;
	}
        
        public void setFlashing()
        {
            flashing = ! flashing;
        }

        public void move()
	{
		x += dx;
		y += dy;

		// and bounce if we hit a wall
		if ( x < 0 || x+20 > 1000 )
			dx = -dx;
		if ( y < 0 || y+20 > 700 )
			dy = -dy;
			
		if ( flashing )
		{
			int r = rng.nextInt(256);
			int g = rng.nextInt(256);
			int b = rng.nextInt(256);
			cur = new Color(r,g,b);
		}
	}
}

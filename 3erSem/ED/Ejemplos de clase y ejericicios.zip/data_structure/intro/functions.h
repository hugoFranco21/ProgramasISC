/*
 * intro.h
 *      Author: pperezm
 */

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

unsigned long fact(int n) {
	return 0;
}

bool isPrime(int n) {
	return false;
}

unsigned long sum(int arr[], int size) {
	return 0;
}

void reverse(int arr[], int size) {
}

#endif /* FUNCTIONS_H_ */

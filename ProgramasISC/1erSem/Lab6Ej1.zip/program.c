#include <stdlib.h>
#include <stdio.h>
#include <math.h>

float potencia (int x, int n);
float sumatoria (int S);
float aproximacion_PI (long int N);

//Esta funcion sirve como un menu, en el que el usuario puede
//elegir que funcion realizar, y con un switch elige el caso 
//que desea, y se evaluan las funciones con los valores dados
//por el usuario. 
//Esta en un ciclo while que solo se detiene si la opcion
//indicada es la 4, que es la de salir.
void main(){
	float pot1, pot2, pot3, pot4, aprox1, aprox2, aprox3, aprox4, aprox5, suma1, suma2, suma3, suma4, r1, r2, r3, r4, r5;
	int opc, x1, n1, x2, n2, x3, n3, x4, n4, q1, q2, q3, q4;
	do{
	printf("FUNCIONES:\n");
	printf("1. Potencia\n");
	printf("2. Evaluar sumatoria\n");
	printf("3. Aproximacion del valor de PI\n");
	printf("4. Salir\n");
	printf("Opcion: ");
	scanf("%d", &opc);
	system("pause");
	system("cls");
	
	switch(opc)
	{
		case 1:
			printf("Escriba el valor de la base\n");
			scanf("%d", &x1);
			printf("Escriba el valor del exponente\n");
			scanf("%d",&n1);
			printf("Escriba el valor de la base\n");
			scanf("%d", &x2);
			printf("Escriba el valor del exponente\n");
			scanf("%d",&n2);
			printf("Escriba el valor de la base\n");
			scanf("%d", &x3);
			printf("Escriba el valor del exponente\n");
			scanf("%d",&n3);
			printf("Escriba el valor de la base\n");
			scanf("%d", &x4);
			printf("Escriba el valor del exponente\n");
			scanf("%d",&n4);
			pot1 = potencia (x1,n1);
			pot2 = potencia (x2,n2);
			pot3 = potencia (x3,n3);
			pot4 = potencia (x4,n4);
			system("pause");
			system("cls");
			printf("Input:\n%d\n%d %d\n",opc, x1, n1);
			printf("Output:\n%0.0f\n\n", pot1);
			printf("Input:\n%d\n%d %d\n",opc, x2, n2);
			printf("Output:\n%0.0f\n\n", pot2);
			printf("Input:\n%d\n%d %d\n",opc, x3, n3);
			printf("Output:\n%0.0f\n\n", pot3);
			printf("Input:\n%d\n%d %d\n",opc, x4, n4);
			printf("Output:\n%0.0f\n\n", pot4);		
			system("pause");
			system("cls");
			break;
		
		case 2:
			printf("Escriba el numero de terminos que quiere para la sumatoria\n");
			scanf("%d",&q1);
			printf("Escriba el numero de terminos que quiere para la sumatoria\n");
			scanf("%d",&q2);
			printf("Escriba el numero de terminos que quiere para la sumatoria\n");
			scanf("%d",&q3);
			printf("Escriba el numero de terminos que quiere para la sumatoria\n");
			scanf("%d",&q4);
			system("pause");
			system("cls");
			suma1 = sumatoria (q1);
			suma2 = sumatoria (q2);
			suma3 = sumatoria (q3);
			suma4 = sumatoria (q4);
			printf("Input:\n%d\n%d\n",opc, q1);
			printf("Output:\n%0.1f\n\n", suma1);
			printf("Input:\n%d\n%d\n",opc, q2);
			printf("Output:\n%0.1f\n\n", suma2);
			printf("Input:\n%d\n%d\n",opc, q3);
			printf("Output:\n%0.1f\n\n", suma3);
			printf("Input:\n%d\n%d\n",opc, q4);
			printf("Output:\n%0.1f\n\n", suma4);
			system("pause");
			system("cls");
			break;
			
		case 3:
			printf("Escriba el numero de elementos de la serie de Leibniz que quiere utilizar\n");
			scanf("%f", &r1);
			printf("Escriba el numero de elementos de la serie de Leibniz que quiere utilizar\n");
			scanf("%f", &r2);
			printf("Escriba el numero de elementos de la serie de Leibniz que quiere utilizar\n");
			scanf("%f", &r3);
			printf("Escriba el numero de elementos de la serie de Leibniz que quiere utilizar\n");
			scanf("%f", &r4);
			printf("Escriba el numero de elementos de la serie de Leibniz que quiere utilizar\n");
			scanf("%f", &r5);
			system("pause");
			system("cls");
			aprox1 = aproximacion_PI(r1);
			aprox2 = aproximacion_PI(r2);
			aprox3 = aproximacion_PI(r3);
			aprox4 = aproximacion_PI(r4);
			aprox5 = aproximacion_PI(r5);
			printf("Input:\n%d\n%0.0f\n", opc, r1);
			if (aprox1 == 0){
			printf("No se puede usar 0\n\n");
			} else if (aprox1 > 0){
			printf("Output:\n%0.1f\n\n", aprox1);
			} else {
			printf("Debe ingresar un numero natural\n\n");
			}
			printf("Input:\n%d\n%0.0f\n", opc, r2);
			if (aprox2 == 0){
			printf("No se puede usar 0\n\n");
			} else if (aprox2 > 0){
			printf("Output:\n%0.1f\n\n", aprox2);
			} else {
			printf("Debe ingresar un numero natural\n\n");
			}
			printf("Input:\n%d\n%0.0f\n", opc, r3);
			if (aprox3 == 0){
			printf("No se puede usar 0\n\n");
			} else if (aprox3 > 0){
			printf("Output:\n%0.1f\n\n", aprox3);
			} else {
			printf("Debe ingresar un numero natural\n\n");
			}
			printf("Input:\n%d\n%0.0f\n", opc, r4);
			if (aprox4 == 0){
			printf("No se puede usar 0\n\n");
			} else if (aprox4 > 0){
			printf("Output:\n%0.1f\n\n", aprox4);
			} else {
			printf("Debe ingresar un numero natural\n\n");
			}
			printf("Input:\n%d\n%0.0f\n", opc, r5);
			if (aprox5 == 0){
			printf("No se puede usar 0\n\n");
			} else if (aprox5 > 0){
			printf("Output:\n%0.1f\n", aprox5);
			} else {
			printf("Debe ingresar un numero natural\n\n");
			}
			system("pause");
			system("cls");
			break;
			
		case 4:
			printf("Va a salir del programa\n");
			system("pause");
			break;
		
		default:
			printf("El numero de opcion indicado es incorrecto\n");
			system("pause");
			system("cls");
	}
	} while (opc != 4); 
}

//Como no se si puedo usar la biblioteca math y la instruccion pow(x,y),
//escribi la potencia como una serie de multiplicaciones del mismo numero 
//por si mismo.
//Use un respaldo del numero original para que no se perdiera.
//Los pasos para hallar los valores los escribi con if para tener una mayor
//flexibilidad en mis condiciones 
float potencia (int a, int b){
	float res1, a1;
	a1 = a;
	int i;
	if (b == 0){
		a1 = 1;
	} else if (b == 1){
		a1 = a1;
	} else {
		for (i = 2;i<=b;i++)
		{
		a1 = a*a1;
		}
	}
	return a1;
}

//Para esta funcion, utilice una constante que es del tipo float, que 
//vale 3/4, o 0.75, una variable en la que cuento el numero de terminos 
//que es i, y otra variable en la que llevo el resultado de la suma
//que es lo que regreso a main
float sumatoria(int S){
	float i = 0;
	float sum = 0;
	const float t = 0.75;
	do{
	sum = sum + (sqrt(t*i))/(sqrt(potencia(i,5) + potencia(i,2))+1);
	i = i + 1;
	} while (i <= S);
	return sum;
}

//Para el algoritmo de esta funcion, primero tenia que ver como se
//comportaba la funcion, como son los numeros impares tome la funcion 2x-1
//que su resultado siempre es un numero impar. Otro desafio fue el 
//alternar el signo, pero vi que era sencillo si creaba dos 
//variable que valieran -1, y multiplicaba una con la otra, pero 
//sobreescribia el valor de una para que el signo fuera alternando de 
//positivo a negativo.
float aproximacion_PI (long int N){
	int i;
	float den, term, sum;
	float ini = 0;
	float b = -1;
	float bb = -1;
	if (N == 0){
		return 0;
	} else {
		for(i = 1;i <= N; i++){
		den = b + 2*i;
		term = 4/den;
		bb = bb * b;
		sum = ini + (bb*term);
		ini = sum;
		}
	return ini;
	}
}
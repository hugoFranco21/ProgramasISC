/*
 * recursion.h
 *
 *  Created on: 10/09/2015
 *      Author: pperezm
 */

#ifndef RECURSION_H_
#define RECURSION_H_

#include "exception.h"
#include <iostream>

long sum_seq(int n) {
	return 0;
}

long sum_rec(int n) {
	return 0;
}

long fact_seq(int n) {
	return 0;
}

long fact_rec(int n) {
	return 0;
}

long fib_seq(int n) {
	return 0;
}

long fib_rec(int n) {
	return 0;
}

long gcd_seq(long a, long b) {
	return 0;
}

long gcd_rec(long a, long b) {
	return 0;
}

bool find_seq(int arr[], int size, int val) {
	return false;
}

bool find_rec(int arr[], int low, int high, int val) {
	return false;
}

int max_seq(int arr[], int size) {
	return 0;
}

int max_rec(int arr[], int low, int high) {
	return 0;
}

int unimodal_seq(int arr[], int size) {
	return 0;
}

int unimodal_rec(int arr[], int low, int high) {
	return 0;
}

int unimodal_rec(int arr[], int size) {
	return 0;
}

int bs_seq(int arr[], int size, int val) {
	return 0;
}

int bs_aux(int arr[], int low, int high, int val) {
	return 0;
}

int bs_rec(int arr[], int size, int val) {
	return 0;
}
#endif /* RECURSION_H_ */

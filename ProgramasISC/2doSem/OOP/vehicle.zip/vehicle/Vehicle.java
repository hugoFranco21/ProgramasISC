/*Name: Hugo David Franco Avila
Date: March - 13 - 2018
This class tests the vehicle package, using the class driver
and vehicle
*/
package vehicle;

public abstract class Vehicle{
	
	//Attributes
	protected Driver passenger;
	
	//Methods
	public abstract void start();
	
	public abstract void stop();
	
}
